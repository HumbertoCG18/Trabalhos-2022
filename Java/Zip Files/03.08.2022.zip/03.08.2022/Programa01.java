public class Programa01 {
    public static void main(String[] args) {
    
    int inicio;
    String nome;

    nome= "Humberto";
    inicio = 15;

    if( inicio>10){
    for (int contador = 0; contador < 5 ; contador++){
        System.out.println(nome+" "+contador);
            }
        }
    }
}