class Divi {
    public static void main(String[]args) {
        int x, y, Divi;
        x =  10;
        y = 2;
        
        Divi = x / y;
        
        System.out.print(Divi);
    }
}
