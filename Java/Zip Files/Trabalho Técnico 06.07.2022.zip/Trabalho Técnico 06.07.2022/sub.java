class Sub {
    public static void main(String[]args) {
        int x, y, Sub;
        x =  10;
        y = 2;
        
        Sub = x - y;
        
        System.out.print(Sub);
    }
}
