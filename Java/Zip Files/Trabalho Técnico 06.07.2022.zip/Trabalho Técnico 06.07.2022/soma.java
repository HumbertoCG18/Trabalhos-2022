class Soma {
    public static void main(String[]args) {
        int x, y, Soma;
        x =  10;
        y = 2;
        
        Soma = x + y;
        
        System.out.print(Soma);
    }
}
