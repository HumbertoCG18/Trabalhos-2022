class Multi {
    public static void main(String[]args) {
        int x, y, Multi;
        x =  10;
        y = 2;
        
        Multi = x*y;
        
        System.out.print(Multi);
    }
}
