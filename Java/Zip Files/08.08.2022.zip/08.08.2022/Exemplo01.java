public class Exemplo01{
    public static void main(String[] args){
        for(int i = 1; i<= 5; i++){
            System.out.println("("+i+")");
            for (int x = 1; x <= 5; x++){
                System.out.println(+i" "+x);
            }
            System.out.println("---");
        }
    }
}